﻿using UnityEngine;
using System.Collections;

public class HasManager : MonoBehaviour {

	protected GameManager gameManager;

	public void SetGameManager(GameManager _gameManager) {
		
		gameManager = _gameManager;
	}
}