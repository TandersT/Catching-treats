﻿using UnityEngine;

public class DogTreatController : MonoBehaviour {

    float rotationSpeed = 10;
    float minFallSpeed = 1f;
    float maxFallSpeed = 2.3f;
    float fallSpeed;

    public Transform bowl;
    public float fastestTreat;

    GameManager gM;

    void Start() {
        bowl = GameObject.FindGameObjectWithTag("Bowl").transform;
        fallSpeed = Random.Range(minFallSpeed, maxFallSpeed);
        InvokeRepeating("Gravity", 0, 1f);
        gM = GameObject.FindGameObjectWithTag("Manager").GetComponent<GameManager>();
    }

    void Update() {
        if (gM.gameRunning) {
            transform.position = new Vector3(transform.position.x, transform.position.y - fallSpeed);
            transform.Rotate(Vector3.forward * 7 * fallSpeed);
            fastestTreat = transform.position.y / fallSpeed;
        }
    }

    void Gravity() {
        rotationSpeed += 0.1f;
    }
}
