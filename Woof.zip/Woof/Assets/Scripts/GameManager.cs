﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {
    public bool gameRunning;

    public GameObject bowlPrefab;
    public GameObject dogTreatPrefab;
    public Transform canvasTrans;
    public Text ScoreText;
    public Sprite[] doggies = new Sprite[7];
    public Image currentDog;
    public Transform top, right, left;
    float prevWaitingTime;
    public float waitingTime = 2f;
    private IEnumerator coroutine;
    public bool win = false;
    public Text wonText;
    GameObject tempBowl;
    [SerializeField]
    Transform fastestTreat;

    Arduino _ard;

    public int proximityToBowl;

    private LoggingManager loggingManager;
    private Button startButton;

    private float startTime = 0f;
    private float reactionTime = 0f;
    private Vector2 hitPos;

    int currentTarget;
    float previousReactionTime;

    public float screenWidth;

    void Start() {
        DontDestroyOnLoad(this);
        loggingManager = this.GetComponent<LoggingManager>();

        _ard = GetComponent<Arduino>();

        loggingManager.SetGameManager(this);
        loggingManager.NewLog();

        currentDog.sprite = doggies[0];
        tempBowl = Instantiate(bowlPrefab);
        tempBowl.transform.SetParent(canvasTrans);

        coroutine = WaitAndPrint(waitingTime);
        StartCoroutine(coroutine);
        prevWaitingTime = waitingTime;

        screenWidth = right.position.x + 25;

        gameRunning = true;
    }

    void Update() {

        float bowlScreenWidth = left.position.x + right.position.x;
        proximityToBowl = (int)(255 + Mathf.Abs((fastestTreat.position.x - tempBowl.transform.position.x)) / bowlScreenWidth * -255);

        if (prevWaitingTime != waitingTime) {
            StopAllCoroutines();
            coroutine = WaitAndPrint(waitingTime);
            StartCoroutine(coroutine);
            prevWaitingTime = waitingTime;
        }

        if (win == true) {
            wonText.gameObject.SetActive(true);
            gameRunning = false;
        }
    }

    private IEnumerator WaitAndPrint(float waitTime) {
        while (true) {
            if (gameRunning) {
                float rPos = Random.Range(left.position.x, right.position.x);
                Vector3 spawnPos = new Vector3(rPos, top.position.y, 0);
                GameObject tempTreat = Instantiate(dogTreatPrefab, spawnPos, Quaternion.identity);
                tempTreat.transform.SetParent(canvasTrans);
            }
            yield return new WaitForSeconds(waitTime);
        }
    }

    public void SuccesfulHit(GameObject _treat) {
        previousReactionTime = reactionTime;
        reactionTime = Time.time;
        currentTarget++;
        hitPos = _treat.transform.position;
        MakeLogEntry("Hit");
    }

    public void Miss() {
        MakeLogEntry("Miss");
    }


    private void MakeLogEntry(string _hitType) {

        loggingManager.NewEntry(_hitType,
                                 currentTarget,
                                 reactionTime - previousReactionTime,
                                 hitPos,
                                 66f, //colliderWidth
                                 _ard.IBI,
                                 _ard.RawEDA,
                                 proximityToBowl);
    }

}