﻿using UnityEngine;
using UnityEngine.UI;

public class Bottom : MonoBehaviour {

    public Text healthText;
    public Text lostText;
    int health = 3;
    public GameManager gM;

    void Start() {
        healthText.text = health.ToString();
        gM = GameObject.FindGameObjectWithTag("Manager").GetComponent<GameManager>();
    }

    void OnTriggerEnter2D(Collider2D _col) {
        if (_col.CompareTag("DogTreat")) {
            gM.Miss();
            //Debug.Log("yes");
            Destroy(_col.gameObject);
            health--;
            healthText.text = health.ToString();
            if (health == 0) {
                lostText.gameObject.SetActive(true);
                gM.gameRunning = false;
            }
        }
    }
}
