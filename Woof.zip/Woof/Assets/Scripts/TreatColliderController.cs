﻿using UnityEngine;

public class TreatColliderController : MonoBehaviour {

    GameObject[] treatController;
    public GameObject currentFastest;
    float fastestTreat;

    void Start() {
        fastestTreat = Mathf.Infinity;
    }

    void LateUpdate() {
        treatController = GameObject.FindGameObjectsWithTag("DogTreat");

        foreach (GameObject _dogTreat in treatController) {

            float tempFastestTreat = _dogTreat.GetComponent<DogTreatController>().fastestTreat;

            if (currentFastest == null) {
                fastestTreat = Mathf.Infinity;
            }

            if (tempFastestTreat == 0) {
                return;
            }

            if (fastestTreat > tempFastestTreat) {
                currentFastest = _dogTreat;
                fastestTreat = tempFastestTreat;
                transform.position = _dogTreat.transform.position;
            }
        }
    }
}
