﻿using System.IO;
using UnityEngine;

public class LoggingManager : HasManager {


    private string headers = "Date;Time;HitType;CurrentTarget;ReactionTime;xHitPos;ColliderWidth;IBI;EDA;Proximity;xScreenSize";

    private StreamWriter writer;
    private string directory;
    private string fileName;
    private string sep = ";";
    private string currentEntry;

    private string date;
    private string time;
    [SerializeField]
    private bool wVibrator;

    public void Awake() {


        //Path: C:\Users\littl\AppData\LocalLow\AAU\Woof\DataDog
        if (wVibrator) {
            directory = Application.persistentDataPath + "/DataDog/wVibrator/";
        } else {
            directory = Application.persistentDataPath + "/DataDog/woVibrator/";
        }

        if (!Directory.Exists(directory)) {
            Directory.CreateDirectory(directory);
            Debug.Log("Created directory");
        }
    }

    public void NewEntry(string _hitType,
                         int _targetNumber,
                         float _timeSinceLastHit,
                         Vector2 _hitPos,
                         float _colliderWitdh,
                         float _IBI,
                         float _EDA,
                         float _proximity) {

        date = System.DateTime.Now.ToString("yyyy-MM-dd");
        time = System.DateTime.Now.ToString("HH:mm:ss:ffff");

        currentEntry = date + sep +
                        time + sep +
                        _hitType + sep +
                        _targetNumber + sep +
                        _timeSinceLastHit + sep +
                        _hitPos.x + sep +
                        _colliderWitdh + sep +
                        _IBI + sep +
                        _EDA + sep +
                        _proximity + sep +
                        Screen.width;

        using (StreamWriter writer = File.AppendText(directory + fileName)) {
            writer.WriteLine(currentEntry);
        }
    }

    public void NewLog() {

        fileName = System.DateTime.Now.ToString() + ".txt";
        fileName = fileName.Replace('/', '-');
        fileName = fileName.Replace(':', '-');

        using (StreamWriter writer = File.AppendText(directory + fileName)) {
            writer.WriteLine(headers);
        }
    }
}