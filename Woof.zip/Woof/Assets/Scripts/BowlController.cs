﻿using UnityEngine;

public class BowlController : MonoBehaviour {

    public Transform leftEnd, rightEnd;
    public int yPos;
    public GameManager gM;
    int score = 0;
    bool finalLevel = false;
    bool runOnce = true;
    public ParticleSystem pSystem;
    Sprite prevDog;
    public float pos;

    void Start() {
        pSystem = GameObject.FindGameObjectWithTag("Particle").GetComponent<ParticleSystem>(); ;
        leftEnd = GameObject.FindGameObjectWithTag("LeftEnd").transform;
        rightEnd = GameObject.FindGameObjectWithTag("RightEnd").transform;
        gM = GameObject.FindGameObjectWithTag("Manager").GetComponent<GameManager>();
    }

    void FixedUpdate() {
        if (gM.gameRunning) {
            if (Input.GetKeyDown(KeyCode.Space)) {
                score += 1000;
            }


            float mousePosX = Input.mousePosition.x;
            if (mousePosX < leftEnd.position.x) {
                mousePosX = leftEnd.position.x;
            }
            if (mousePosX > rightEnd.position.x) {
                mousePosX = rightEnd.position.x;
            }

            transform.position = new Vector3(mousePosX, yPos, 0);
            pos = mousePosX;
        }
    }

    void OnTriggerEnter2D(Collider2D _col) {
        if (_col.CompareTag("DogTreat")) {
            prevDog = gM.currentDog.sprite;
            gM.SuccesfulHit(_col.gameObject);
            score += 100;
            gM.ScoreText.text = score.ToString();
            Destroy(_col.gameObject);
            if (score >= 1000 && score < 2000) {
                gM.currentDog.sprite = gM.doggies[1];
                gM.waitingTime = 1.8f;
            } else if (score >= 2000 && score < 3000) {
                gM.currentDog.sprite = gM.doggies[2];
                gM.waitingTime = 1.6f;
            } else if (score >= 3000 && score < 4000) {
                gM.currentDog.sprite = gM.doggies[3];
                gM.waitingTime = 1.4f;
            } else if (score >= 4000 && score < 5000) {
                gM.currentDog.sprite = gM.doggies[4];
                gM.waitingTime = 1.2f;
            } else if (score >= 5000 && score < 6000) {
                gM.currentDog.sprite = gM.doggies[5];
                gM.waitingTime = 1.0f;
            } else if (score >= 6000) {
                gM.currentDog.sprite = gM.doggies[6];
                gM.win = true;
            }
            if (gM.currentDog.sprite != prevDog) {
                pSystem.Play();
                gM.gameRunning = false;
                Invoke("stopParticle", 3f);
            }
        }
    }
    void OnGUI() {
        if (finalLevel) {
            GUI.Box(new Rect(Screen.width / 2 - 450 / 2, Screen.height / 2, 450, 25), "You reached the final level. Reach 10.000 to save ALL the puppers!");
            Invoke("finalOver", 4f);
        }
    }
    void finalOver() {
        finalLevel = false;
    }
    void stopParticle() {
        gM.gameRunning = true;
        pSystem.Stop();
    }
}
